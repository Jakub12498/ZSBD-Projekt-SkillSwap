from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from database import SessionLocal, engine

import models
import schemas

app = FastAPI()

models.Base.metadata.create_all(bind=engine)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# DB
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ROOT
@app.get("/")
def root():
    return {"message": "SkillSwap API"}

# REGISTER
@app.post("/register")
def register(user: schemas.UserCreate,
             db: Session = Depends(get_db)):

    existing = db.query(models.User).filter(
        models.User.email == user.email
    ).first()

    if existing:
        return {"error": "Email exists"}

    new_user = models.User(
        username=user.username,
        email=user.email,
        password_hash=user.password
    )

    db.add(new_user)
    db.commit()

    return {"message": "User created"}

# LOGIN
@app.post("/login")
def login(user: schemas.UserLogin,
          db: Session = Depends(get_db)):

    db_user = db.query(models.User).filter(
        models.User.email == user.email
    ).first()

    if not db_user:
        return {"error": "User not found"}

    if db_user.password_hash != user.password:
        return {"error": "Wrong password"}

    return {
        "message": "success",
        "username": db_user.username
    }

# PROFILE
@app.get("/profile/{username}")
def profile(username: str,
            db: Session = Depends(get_db)):

    user = db.query(models.User).filter(
        models.User.username == username
    ).first()

    return {
        "username": user.username,
        "email": user.email,
        "bio": user.bio,
        "skills": user.skills
    }

# UPDATE PROFILE
@app.post("/profile/update/{username}")
def update_profile(username: str,
                   data: dict,
                   db: Session = Depends(get_db)):

    user = db.query(models.User).filter(
        models.User.username == username
    ).first()

    user.bio = data["bio"]
    user.skills = data["skills"]

    db.commit()

    return {"message": "Profile updated"}

# CREATE OFFER
@app.post("/offers")
def create_offer(
    offer: schemas.OfferCreate,
    db: Session = Depends(get_db)
):

    owner = db.query(models.User).filter(
        models.User.username == offer.owner
    ).first()

    if not owner:
        return {"error": "Owner not found"}

    new_offer = models.Offer(
        title=offer.title,
        description=offer.description,
        category=offer.category,
        owner_id=owner.id
    )

    db.add(new_offer)

    db.commit()

    return {"message": "Offer created"}

# GET OFFERS
@app.get("/offers")
def get_offers(db: Session = Depends(get_db)):

    offers = db.query(models.Offer).all()

    result = []

    for offer in offers:

        owner = db.query(models.User).filter(
            models.User.id == offer.owner_id
        ).first()

        result.append({
            "id": offer.id,
            "title": offer.title,
            "description": offer.description,
            "category": offer.category,
            "owner": owner.username
        })

    return result

# SEND MESSAGE
@app.post("/messages")
def send_message(message: schemas.MessageCreate,
                 db: Session = Depends(get_db)):

    new_message = models.Message(
        sender=message.sender,
        receiver=message.receiver,
        content=message.content,
        offer_id=message.offer_id
    )

    db.add(new_message)
    db.commit()

    return {"message": "Message sent"}

# GET MESSAGES
@app.get("/messages/{username}")
def get_messages(username: str,
                 db: Session = Depends(get_db)):

    messages = db.query(models.Message).filter(
        models.Message.receiver == username
    ).all()

    return messages