from pydantic import BaseModel

class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class OfferCreate(BaseModel):
    title: str
    description: str
    category: str
    owner: str

class MessageCreate(BaseModel):
    sender: str
    receiver: str
    content: str
    offer_id: int