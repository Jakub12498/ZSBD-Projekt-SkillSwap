from sqlalchemy import Column, Integer, String, Text, ForeignKey
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)

    username = Column(String)
    email = Column(String)
    password_hash = Column(Text)

    bio = Column(Text, default="")
    skills = Column(Text, default="")


class Offer(Base):
    __tablename__ = "offers"

    id = Column(Integer, primary_key=True)

    title = Column(String)
    description = Column(Text)
    category = Column(String)

    owner_id = Column(Integer, ForeignKey("users.id"))


class Message(Base):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True)

    sender = Column(String)
    receiver = Column(String)

    content = Column(Text)

    offer_id = Column(Integer)